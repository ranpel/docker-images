SET VERIFY OFF
set echo on
spool /opt/oracle/crdb/PDBCreation.log append
